package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.MethodDescriptor;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class BancoTest {

	final Banco pojo = new Banco();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;

	AuditoriaProcessamento ap = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Banco obj = new Banco();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Banco.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}

		MethodDescriptor[] methodDescriptor = Introspector.getBeanInfo(Banco.class).getMethodDescriptors();
		for (MethodDescriptor method : methodDescriptor) {
			System.out.println(method.getName());
		}

	}

	@Test
	public void testaConstrutores() {
		Banco.builder().toString();
		Banco.builder().build().toBuilder();
		assertThat(Banco.builder().auditoriaProcessamento(ap).build(), hasProperty("auditoriaProcessamento"));
		assertThat(Banco.builder().cep(string).build(), hasProperty("cep"));
		assertThat(Banco.builder().cidade(string).build(), hasProperty("cidade"));
		assertThat(Banco.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(Banco.builder().codigoBanco(integer).build(), hasProperty("codigoBanco"));
		assertThat(Banco.builder().dataAberturaAgencia(date).build(), hasProperty("dataAberturaAgencia"));
		assertThat(Banco.builder().dataFechamentoAgencia(date).build(), hasProperty("dataFechamentoAgencia"));
		assertThat(Banco.builder().dtHrProcessamento(date).build(), hasProperty("dtHrProcessamento"));
		assertThat(Banco.builder().endereco(string).build(), hasProperty("endereco"));
		assertThat(Banco.builder().id(integer).build(), hasProperty("id"));
		assertThat(Banco.builder().nomeAgencia(string).build(), hasProperty("nomeAgencia"));
		assertThat(Banco.builder().numeroAgencia(integer).build(), hasProperty("numeroAgencia"));
		assertThat(Banco.builder().pais(string).build(), hasProperty("pais"));
		assertThat(Banco.builder().periodo(integer).build(), hasProperty("periodo"));
		assertThat(Banco.builder().telefone(string).build(), hasProperty("telefone"));
		assertThat(Banco.builder().uf(string).build(), hasProperty("uf"));
		assertThat(Banco.builder().versao(integer).build(), hasProperty("versao"));

	}

	@Test
	public void testeSetterDataAberturaAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataAberturaAgencia(date);
		final Field field = pojo.getClass().getDeclaredField("dataAberturaAgencia");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeSetterEndereco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setEndereco(string);
		final Field field = pojo.getClass().getDeclaredField("endereco");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterVersao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setVersao(integer);
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));

	}

	@Test
	public void testeSetterCep() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCep(string);
		final Field field = pojo.getClass().getDeclaredField("cep");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));

	}

	@Test
	public void testeGetterCep() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cep");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCep();
		assertEquals(string, result);

	}

	@Test
	public void testeSetterPais() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPais(string);
		final Field field = pojo.getClass().getDeclaredField("pais");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCidade() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCidade(string);
		final Field field = pojo.getClass().getDeclaredField("cidade");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeGetterNomeAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeAgencia");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeAgencia();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPeriodo();
		assertEquals(integer, result);
	}

	@Test
	public void testeSetterUf() throws NoSuchFieldException, IllegalAccessException {
		pojo.setUf(string);
		final Field field = pojo.getClass().getDeclaredField("uf");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTelefone() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTelefone(string);
		final Field field = pojo.getClass().getDeclaredField("telefone");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoBanco(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));

	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));

	}

	@Test
	public void testeGetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		field.set(pojo, ap);
		final AuditoriaProcessamento result = pojo.getAuditoriaProcessamento();
		assertEquals(ap, result);

	}

	@Test
	public void testeGetterTelefone() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("telefone");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getTelefone();
		assertEquals(string, result);

	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(integer);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAuditoriaProcessamento(ap);
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		assertEquals(ap, field.get(pojo));
	}

	@Test
	public void testeGetterEndereco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("endereco");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getEndereco();
		assertEquals(string, result);

	}

	@Test
	public void testeSetterNomeAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeAgencia(string);
		final Field field = pojo.getClass().getDeclaredField("nomeAgencia");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));

	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);

	}

	@Test
	public void testeGetterDataAberturaAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataAberturaAgencia");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDataAberturaAgencia();
		assertEquals(date, result);

	}

	@Test
	public void testeGetterPais() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("pais");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getPais();
		assertEquals(string, result);

	}

	@Test
	public void testeSetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPeriodo(integer);
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getNumeroAgencia();
		assertEquals(integer, result);

	}

	@Test
	public void testeSetterDataFechamentoAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataFechamentoAgencia(date);
		final Field field = pojo.getClass().getDeclaredField("dataFechamentoAgencia");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeGetterUf() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("uf");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getUf();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterVersao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getVersao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterDataFechamentoAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataFechamentoAgencia");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDataFechamentoAgencia();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtHrProcessamento();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterCidade() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cidade");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCidade();
		assertEquals(string, result);

	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));

	}

	@Test
	public void testeSetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrProcessamento(date);
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));

	}

	@Test
	public void testeGetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoBanco();
		assertEquals(integer, result);
	}

	@Test
	public void testaBuild() {
		Banco banco = Banco.builder().build();
		assertNotNull(banco);

		Banco banco2 = Banco.builder().auditoriaProcessamento(AuditoriaProcessamento.builder().build()).cep("")
				.cidade("").codigo("").codigoBanco(1).dataAberturaAgencia(new Date()).dataFechamentoAgencia(new Date())
				.dtHrProcessamento(new Date()).endereco("").id(1).nomeAgencia("").numeroAgencia(1).pais("").periodo(1)
				.telefone("").build();
		String banco3 = Banco.builder().build().toString();

		assertFalse(banco3.isEmpty());
		assertNotNull(banco2);

	}
}
