package br.com.caixa.sidce.arquitetura;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.dto.DataHoraDTO;

@RunWith(MockitoJUnitRunner.class)
public class DataHoraTest {
	@Test
	public void testDataHora() throws IOException {
		DataHoraDTO actual = new ObjectMapper().readValue("{\"data\":" + "\"2015-10-07 20:00\"" + "}", DataHoraDTO.class);

		Calendar c = Calendar.getInstance();
		c.setTime(actual.getData());
		
		assertEquals(2015, c.get(Calendar.YEAR));
		assertEquals(10, c.get(Calendar.MONTH) + 1);
		assertEquals(07, c.get(Calendar.DAY_OF_MONTH));
		assertEquals(20, c.get(Calendar.HOUR_OF_DAY));
		assertEquals(00, c.get(Calendar.MINUTE));
	}
	
	@Test
	public void testData() throws IOException {
		DataHoraDTO actual = new ObjectMapper().readValue("{\"data\":" + "\"2015-10-07\"" + "}", DataHoraDTO.class);

		Calendar c = Calendar.getInstance();
		c.setTime(actual.getData());
		
		assertEquals(2015, c.get(Calendar.YEAR));
		assertEquals(10, c.get(Calendar.MONTH) + 1);
		assertEquals(07, c.get(Calendar.DAY_OF_MONTH));
	}
	
	@Test
	public void testFormatoDesconhecido() throws IOException {
		DataHoraDTO actual = new ObjectMapper().readValue("{\"data\":" + "\"20151007\"" + "}", DataHoraDTO.class);
		assertEquals(actual.getData(), null);
	}
	
	@Test
	public void testParseException() throws IOException {
		new ObjectMapper().readValue("{\"data\":" + "\"5555-55-55\"" + "}", DataHoraDTO.class);
	}
	
	@Test
	public void testSerializeDateIntoJson() throws IOException {
		
		DataHoraDTO a = new DataHoraDTO();
		
		LocalDate d = LocalDate.of(2015, 10, 07);
		a.setData(java.sql.Date.valueOf(d));
		
		String actual = new ObjectMapper().writeValueAsString(a);
		
		assertEquals("{\"data\":" + "\"2015-10-07 00:00\"" + "}", actual);
		
	}
}
