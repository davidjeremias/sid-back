package br.com.caixa.sidce.interfaces.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.application.ApplicationTest;
import br.com.caixa.sidce.domain.model.Auditoria;
import br.com.caixa.sidce.domain.service.AuditoriaService;
import br.com.caixa.sidce.interfaces.util.FileStorage;
import br.com.caixa.sidce.util.infraestructure.service.RestFullService;



@RunWith(SpringRunner.class)
@WebAppConfiguration
@WebMvcTest(controllers  = {AuditoriaController.class}, secure = false)
@ContextConfiguration(classes={ApplicationTest.class})
public class AuditoriaControllerTest  {
	
	 	@Autowired
	    protected MockMvc mockMvc;
	    
	    @MockBean
	    private AuditoriaService service;
	    
	    @MockBean
	    private FileStorage file;
	    
	    @Mock
		private Principal principal = Mockito.mock(Principal.class);
	    
	    private ObjectMapper mapper = new ObjectMapper();
	    
	    @Autowired
	    private RestFullService restfullService;
	    
	    @Before
	    public void setup() throws Exception{
	    	when(principal.getName()).thenReturn("user");
	        AuditoriaController auditoriaController = new AuditoriaController(service);       
	        mockMvc = MockMvcBuilders.standaloneSetup(auditoriaController, file, service).build();
	    }
    
	    @Test
	    public void getFuncionalidadesEmpty() throws Exception {
    	
	        mockMvc.perform(get("/api/auditoria/funcionalidades")
	              .contentType(MediaType.APPLICATION_JSON)
	              .accept(MediaType.APPLICATION_JSON))
	              .andDo(print())
	              .andExpect(status().is2xxSuccessful());
	    }
	    @Test
	    public void getFuncionalidadesOk() throws Exception {
	    	List<String> content = new ArrayList<>();
	    	content.add("Funcionalidade1");
	    	content.add("Funcionalidade2");
	    	
	    	when(service.funcionalidadesDisponiveis()).thenReturn(content);
	    	
	    	mockMvc.perform(get("/api/auditoria/funcionalidades")
	    			.content(mapper.writeValueAsString(content))
	    			.contentType(MediaType.APPLICATION_JSON)
	    			.accept(MediaType.APPLICATION_JSON))
	    			.andDo(print())
	    			.andExpect(status().isOk());
	    }
	    
	    @Test
	    public void getEventosEmpty() throws Exception {
	    	
	    	mockMvc.perform(get("/api/auditoria/eventos")
	    			.contentType(MediaType.APPLICATION_JSON)
	    			.accept(MediaType.APPLICATION_JSON))
	    	.andDo(print())
	    	.andExpect(status().is2xxSuccessful());
	    }
	    @Test
	    public void getEventos() throws Exception {
	    	List<String> content = new ArrayList<>();
	    	content.add("Evento1");
	    	content.add("Evento2");
	    	
	    	Map<String, String[]> filter = new HashMap<>();
	    	
	    	when(service.eventosDisponiveis(filter)).thenReturn(content);
	    	
	    	mockMvc.perform(get("/api/auditoria/eventos")
	    			.content(mapper.writeValueAsString(content))
	    			.contentType(MediaType.APPLICATION_JSON)
	    			.accept(MediaType.APPLICATION_JSON))
	    	.andDo(print())
	    	.andExpect(status().isOk());
	    }
	    
}

