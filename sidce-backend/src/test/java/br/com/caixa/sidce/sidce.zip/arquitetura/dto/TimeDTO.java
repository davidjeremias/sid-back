package br.com.caixa.sidce.arquitetura.dto;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.TimeDeserializer;
import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.TimeSerializer;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimeDTO {

	@JsonSerialize(using=TimeSerializer.class)
	@JsonDeserialize(using=TimeDeserializer.class)
	private Date data;

}
