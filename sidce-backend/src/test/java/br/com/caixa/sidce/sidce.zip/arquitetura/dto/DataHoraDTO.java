package br.com.caixa.sidce.arquitetura.dto;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.DataHoraDeserializer;
import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.DataHoraSerializer;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataHoraDTO {
	
	@JsonSerialize(using=DataHoraSerializer.class)
	@JsonDeserialize(using=DataHoraDeserializer.class)
	private Date data;

}
