package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import br.com.caixa.sidce.util.infraestructure.auditoria.TipoEventoAuditoriaEnum;

@RunWith(MockitoJUnitRunner.class)
public class AuditoriaTest {

	final Auditoria pojo = new Auditoria();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Long valorLong = 1L;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Auditoria obj = new Auditoria();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Auditoria.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		Auditoria.builder().build().toBuilder();

		Auditoria.builder().toString();
		assertThat(Auditoria.builder().dtHrAuditoria(date).build(), hasProperty("dtHrAuditoria"));
		assertThat(Auditoria.builder().funcionalidade(string).build(), hasProperty("funcionalidade"));
		assertThat(Auditoria.builder().host(string).build(), hasProperty("host"));
		assertThat(Auditoria.builder().id(integer).build(), hasProperty("id"));
		assertThat(Auditoria.builder().matricula(string).build(), hasProperty("matricula"));

	}

	@Test
	public void testeGetterTipoEvento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoEvento");
		field.setAccessible(true);
		field.set(pojo, TipoEventoAuditoriaEnum.BUSCA);
		final TipoEventoAuditoriaEnum result = pojo.getTipoEvento();
		assertEquals(TipoEventoAuditoriaEnum.BUSCA, result);
	}

	@Test
	public void testeGetterHost() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("host");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getHost();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterFuncionalidade() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("funcionalidade");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getFuncionalidade();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterDtHrAuditoria() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrAuditoria");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtHrAuditoria();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getMatricula();
		assertEquals(string, result);
	}

	@Test
	public void testeSetterFuncionalidade() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFuncionalidade(string);
		final Field field = pojo.getClass().getDeclaredField("funcionalidade");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		pojo.setMatricula(string);
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDtHrAuditoria() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrAuditoria(date);
		final Field field = pojo.getClass().getDeclaredField("dtHrAuditoria");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeSetterHost() throws NoSuchFieldException, IllegalAccessException {
		pojo.setHost(string);
		final Field field = pojo.getClass().getDeclaredField("host");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTipoEvento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoEvento(TipoEventoAuditoriaEnum.BUSCA);
		final Field field = pojo.getClass().getDeclaredField("tipoEvento");
		field.setAccessible(true);
		assertEquals(TipoEventoAuditoriaEnum.BUSCA, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
