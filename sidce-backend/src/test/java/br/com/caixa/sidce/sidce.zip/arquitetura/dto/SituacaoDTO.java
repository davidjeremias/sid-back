package br.com.caixa.sidce.arquitetura.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.caixa.sidce.util.infraestructure.domain.model.SituacaoAtivo;
import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.SituacaoAtivoDeserializer;
import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.SituacaoAtivoSerializer;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SituacaoDTO {

	@JsonSerialize(using=SituacaoAtivoSerializer.class)
	@JsonDeserialize(using=SituacaoAtivoDeserializer.class)
	private SituacaoAtivo situacao;

}
