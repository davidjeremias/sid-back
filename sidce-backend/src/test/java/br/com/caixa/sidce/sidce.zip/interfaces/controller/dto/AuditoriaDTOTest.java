package br.com.caixa.sidce.interfaces.controller.dto;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import br.com.caixa.sidce.interfaces.web.dto.AuditoriaDTO;

public class AuditoriaDTOTest {

	final AuditoriaDTO pojo = AuditoriaDTO.builder().build();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	@Test
	public void testaPropriedades() throws IntrospectionException {
		AuditoriaDTO obj = AuditoriaDTO.builder().build();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(AuditoriaDTO.class)
				.getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		AuditoriaDTO.builder().build().toBuilder();

		AuditoriaDTO.builder().toString();
		assertThat(AuditoriaDTO.builder().dtFim(date).build(), hasProperty("dtFim"));
		assertThat(AuditoriaDTO.builder().dtInicio(date).build(), hasProperty("dtInicio"));
		assertThat(AuditoriaDTO.builder().evento(string).build(), hasProperty("evento"));
		assertThat(AuditoriaDTO.builder().funcionalidade(string).build(), hasProperty("funcionalidade"));
		assertThat(AuditoriaDTO.builder().matricula(string).build(), hasProperty("matricula"));

	}

	@Test
	public void testeGetterEvento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("evento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getEvento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterFuncionalidade() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("funcionalidade");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getFuncionalidade();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDtFim() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtFim");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtFim();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterDtInicio() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtInicio");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtInicio();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getMatricula();
		assertEquals(string, result);
	}

	@Test
	public void testeSetterFuncionalidade() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFuncionalidade(string);
		final Field field = pojo.getClass().getDeclaredField("funcionalidade");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		pojo.setMatricula(string);
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDtInicio() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtInicio(date);
		final Field field = pojo.getClass().getDeclaredField("dtInicio");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeSetterEvento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setEvento(string);
		final Field field = pojo.getClass().getDeclaredField("evento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDtFim() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtFim(date);
		final Field field = pojo.getClass().getDeclaredField("dtFim");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

}
