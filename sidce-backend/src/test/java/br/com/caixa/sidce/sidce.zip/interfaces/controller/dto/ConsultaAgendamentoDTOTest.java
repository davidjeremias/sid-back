package br.com.caixa.sidce.interfaces.controller.dto;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.lang.reflect.Field;
import java.util.Date;

import org.junit.Test;

import br.com.caixa.sidce.interfaces.web.dto.ConsultaAgendamentoDTO;

public class ConsultaAgendamentoDTOTest {
	
	final ConsultaAgendamentoDTO pojo = new ConsultaAgendamentoDTO();
	private Date data = new Date();
	
	@Test
	public void testaPropriedades() {
		ConsultaAgendamentoDTO dto = new ConsultaAgendamentoDTO();
		assertThat(dto, hasProperty("id"));
		assertThat(dto, hasProperty("solicitante"));
		assertThat(dto, hasProperty("periodo"));
		assertThat(dto, hasProperty("dataUpload"));
		assertThat(dto, hasProperty("dataGeracaoArquivo"));
		assertThat(dto, hasProperty("inicioDataGeracaoArquivo"));
		assertThat(dto, hasProperty("fimDataGeracaoArquivo"));
		assertThat(dto, hasProperty("codigo"));
	}
	
	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(1);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(1, field.get(pojo), "ConsultaAgendamentoDTO.setId");
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, 123);
		final int result = pojo.getId();
		assertEquals(123, result, "ConsultaAgendamentoDTO.getId");
	}
	
	@Test
	public void testeSetterSolicitante() throws NoSuchFieldException, IllegalAccessException {
		pojo.setSolicitante("P123456");
		final Field field = pojo.getClass().getDeclaredField("solicitante");
		field.setAccessible(true);
		assertEquals("P123456", field.get(pojo), "ConsultaAgendamentoDTO.setSolicitante");
	}

	@Test
	public void testeGetterSolicitante() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("solicitante");
		field.setAccessible(true);
		field.set(pojo, "123456789");
		final String result = pojo.getSolicitante();
		assertEquals("123456789", result, "ConsultaAgendamentoDTO.getSolicitante");
	}
	
	@Test
	public void testeSetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPeriodo(201812);
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		assertEquals(201812, field.get(pojo), "ConsultaAgendamentoDTO.setPeriodo");
	}

	@Test
	public void testeGetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		field.set(pojo, 201901);
		final int result = pojo.getPeriodo();
		assertEquals(201901, result, "ConsultaAgendamentoDTO.getPeriodo");
	}
	
	@Test
	public void testeSetterDataUpload() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataUpload(data);
		final Field field = pojo.getClass().getDeclaredField("dataUpload");
		field.setAccessible(true);
		assertEquals(data, field.get(pojo), "ConsultaAgendamentoDTO.setDataUpload");
	}

	@Test
	public void testeGetterDataUpload() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataUpload");
		field.setAccessible(true);
		field.set(pojo, data);
		final Date result = pojo.getDataUpload();
		assertEquals(data, result, "ConsultaAgendamentoDTO.getDataUpload");
	}
	@Test
	public void testeSetterDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataGeracaoArquivo(data);
		final Field field = pojo.getClass().getDeclaredField("dataGeracaoArquivo");
		field.setAccessible(true);
		assertEquals(data, field.get(pojo), "ConsultaAgendamentoDTO.setDataGeracaoArquivo");
	}

	@Test
	public void testeGetterDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataGeracaoArquivo");
		field.setAccessible(true);
		field.set(pojo, data);
		final Date result = pojo.getDataGeracaoArquivo();
		assertEquals(data, result, "ConsultaAgendamentoDTO.getDataGeracaoArquivo");
	}
	
	@Test
	public void testeSetterInicioDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setInicioDataGeracaoArquivo("127.0.0.1");
		final Field field = pojo.getClass().getDeclaredField("inicioDataGeracaoArquivo");
		field.setAccessible(true);
		assertEquals("127.0.0.1", field.get(pojo), "ConsultaAgendamentoDTO.setInicioDataGeracaoArquivo");
	}

	@Test
	public void testeGetterInicioDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("inicioDataGeracaoArquivo");
		field.setAccessible(true);
		field.set(pojo, "inicioDataGeracaoArquivoAqui");
		final String result = pojo.getInicioDataGeracaoArquivo();
		assertEquals("inicioDataGeracaoArquivoAqui", result, "ConsultaAgendamentoDTO.getInicioDataGeracaoArquivo");
	}
	
	@Test
	public void testeSetterFimDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFimDataGeracaoArquivo("127.0.0.1");
		final Field field = pojo.getClass().getDeclaredField("fimDataGeracaoArquivo");
		field.setAccessible(true);
		assertEquals("127.0.0.1", field.get(pojo), "ConsultaAgendamentoDTO.setFimDataGeracaoArquivo");
	}

	@Test
	public void testeGetterFimDataGeracaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("fimDataGeracaoArquivo");
		field.setAccessible(true);
		field.set(pojo, "fimDataGeracaoArquivoAqui");
		final String result = pojo.getFimDataGeracaoArquivo();
		assertEquals("fimDataGeracaoArquivoAqui", result, "ConsultaAgendamentoDTO.getFimDataGeracaoArquivo");
	}
	
	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo("127.0.0.1");
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals("127.0.0.1", field.get(pojo), "ConsultaAgendamentoDTO.setCodigo");
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, "codigoAqui");
		final String result = pojo.getCodigo();
		assertEquals("codigoAqui", result, "ConsultaAgendamentoDTO.getCodigo");
	}
}


