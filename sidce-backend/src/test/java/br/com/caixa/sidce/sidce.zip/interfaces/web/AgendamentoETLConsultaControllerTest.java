package br.com.caixa.sidce.interfaces.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.application.ApplicationTest;
import br.com.caixa.sidce.domain.model.AgendamentoETL;
import br.com.caixa.sidce.domain.service.AgendamentoETLConsultaService;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@WebMvcTest(controllers = { AgendamentoETLConsultaController.class }, secure = false)
@ContextConfiguration(classes = { ApplicationTest.class })
public class AgendamentoETLConsultaControllerTest {

	@Autowired
	protected MockMvc mockMvc;

	@Mock
	private Principal principal = Mockito.mock(Principal.class);

	@MockBean
	private AgendamentoETLConsultaService service;

	private ObjectMapper mapper = new ObjectMapper();

	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	@Before
	public void setup() throws Exception {
		AgendamentoETLConsultaController agendamentoController = new AgendamentoETLConsultaController(service);
		mockMvc = MockMvcBuilders.standaloneSetup(agendamentoController).build();
	}

	@Test
	public void getPeriodoInformacaoGeradosNotContent() throws Exception {

		mockMvc.perform(get("/api/consultaArquivos/periodosInformacaoGerados").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isNoContent());
	}

	@Test
	public void getPeriodoInformacaoGeradosOk() throws Exception {

		List<Integer> periodos = new ArrayList<>();
		periodos.add(1);

		when(service.buscaPeriodosGerados()).thenReturn(periodos);

		mockMvc.perform(
				get("/api/consultaArquivos/periodosInformacaoGerados").content(mapper.writeValueAsString(periodos))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andDo(print()).andExpect(status().isOk());
	}

	@Test
	public void getExecutadosPorAplicacaoNotContent() throws Exception {

		mockMvc.perform(get("/api/consultaArquivos/executadosPorAplicacao").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isNoContent());
	}

	@Test
	public void getProcessosNaFilaNoContent() throws Exception {

		mockMvc.perform(get("/api/consultaArquivos/processosGeracaoConsultaNaFila")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(status().isNoContent());
	}

	@Test
	public void getExecutadosPorAplicacaoOk() throws Exception {

		List<AgendamentoETL> periodos = new ArrayList<AgendamentoETL>();

		periodos.add(AgendamentoETL.builder().matricula("").periodo(201801).descricaoEvento("desc")
				.dtHoraCadastro(new Date()).dtHrProcessamento(new Date()).nomeArquivoCandidato("")
				.nomeArquivoPartido("").codigo("").hostname("").build());

		when(service.executadosPorAplicacao()).thenReturn(periodos);

		mockMvc.perform(get("/api/consultaArquivos/executadosPorAplicacao").content(mapper.writeValueAsString(periodos))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(status().isOk());
	}

	@Test
	public void getSolicitaGeracaoConsultaTest() throws Exception {
		when(principal.getName()).thenReturn("user");

		mockMvc.perform(get("/api/consultaArquivos/solicitaGeracaoConsulta")
					.principal(principal)
					.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
}
