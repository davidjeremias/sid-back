package br.com.caixa.sidce.arquitetura;

import org.junit.Test;

import br.com.caixa.sidce.util.infraestructure.exception.ChamadaInvalidaException;
import br.com.caixa.sidce.util.infraestructure.exception.GeneralRunTimeException;
import br.com.caixa.sidce.util.infraestructure.exception.InternalException;
import br.com.caixa.sidce.util.infraestructure.exception.NegocioException;
import br.com.caixa.sidce.util.infraestructure.exception.NotFoundException;
import br.com.caixa.sidce.util.infraestructure.exception.RegistroExistenteException;

public class ExceptionTest {
	
	@Test(expected = InternalException.class)
	public void testeInternalException_0() throws Exception {
	    throw new InternalException();
	}

	@Test(expected = InternalException.class)
	public void testeInternalException_1() throws Exception {
	    throw new InternalException("");
	}
	
	@Test(expected = InternalException.class)
	public void testeInternalException_2() throws Exception {
	    throw new InternalException(new NegocioException());
	}
	
	@Test(expected = InternalException.class)
	public void testeInternalException_3() throws Exception {
	    throw new InternalException("",new NegocioException());
	}
	
	/**
	 * #########################################
	 * @throws ChamadaInvalidaException
	 */
	
	@Test(expected = ChamadaInvalidaException.class)
	public void testeChamadaInvalidaException_0() throws ChamadaInvalidaException {
	    throw new ChamadaInvalidaException();
	}

	@Test(expected = ChamadaInvalidaException.class)
	public void testeChamadaInvalidaException_1() throws ChamadaInvalidaException {
	    throw new ChamadaInvalidaException("");
	}
	
	@Test(expected = ChamadaInvalidaException.class)
	public void testeChamadaInvalidaException_2() throws ChamadaInvalidaException {
	    throw new ChamadaInvalidaException(new NegocioException());
	}
	
	@Test(expected = ChamadaInvalidaException.class)
	public void testeChamadaInvalidaException_3() throws ChamadaInvalidaException {
	    throw new ChamadaInvalidaException("",new NegocioException());
	}
	
	/**
	 * #########################################
	 * @throws GeneralRunTimeException
	 */
	
	@Test(expected = GeneralRunTimeException.class)
	public void testeGeneralRunTimeException_0() throws GeneralRunTimeException {
	    throw new GeneralRunTimeException();
	}

	@Test(expected = GeneralRunTimeException.class)
	public void testeGeneralRunTimeException_1() throws GeneralRunTimeException {
	    throw new GeneralRunTimeException("");
	}
	
	@Test(expected = GeneralRunTimeException.class)
	public void testeGeneralRunTimeException_2() throws GeneralRunTimeException {
	    throw new GeneralRunTimeException(new NegocioException());
	}
	
	@Test(expected = GeneralRunTimeException.class)
	public void testeGeneralRunTimeException_3() throws GeneralRunTimeException {
	    throw new GeneralRunTimeException("",new NegocioException());
	}
	
	/**
	 * ####################################
	 * @throws NegocioException
	 */
	
	@Test(expected = NegocioException.class)
	public void testeNegocioException_0() throws NegocioException {
	    throw new NegocioException();
	}

	@Test(expected = NegocioException.class)
	public void testeNegocioException_1() throws NegocioException {
	    throw new NegocioException("");
	}
	
	@Test(expected = NegocioException.class)
	public void testeNegocioException_2() throws NegocioException {
	    throw new NegocioException(new NegocioException());
	}
	
	@Test(expected = NegocioException.class)
	public void testeNegocioException_3() throws NegocioException {
	    throw new NegocioException("",new NegocioException());
	}
	
	/**
	 * ##################
	 * @throws NotFoundException
	 */
	
	@Test(expected = NotFoundException.class)
	public void testeNotFoundException_0() throws NotFoundException {
	    throw new NotFoundException();
	}

	@Test(expected = NotFoundException.class)
	public void testeNotFoundException_1() throws NotFoundException {
	    throw new NotFoundException("");
	}
	
	@Test(expected = NotFoundException.class)
	public void testeNotFoundException_2() throws NotFoundException {
	    throw new NotFoundException(new NotFoundException());
	}
	
	@Test(expected = NotFoundException.class)
	public void testeNotFoundException_3() throws NotFoundException {
	    throw new NotFoundException("",new NotFoundException());
	}
	
	

	/**
	 * ##################
	 * @throws RegistroExistenteException
	 */
	
	@Test(expected = RegistroExistenteException.class)
	public void testeRegistroExistenteException_0() throws RegistroExistenteException {
	    throw new RegistroExistenteException();
	}

	@Test(expected = RegistroExistenteException.class)
	public void testeRegistroExistenteException_1() throws RegistroExistenteException {
	    throw new RegistroExistenteException("");
	}
	
	@Test(expected = RegistroExistenteException.class)
	public void testeRegistroExistenteException_2() throws RegistroExistenteException {
	    throw new RegistroExistenteException(new RegistroExistenteException());
	}
	
	@Test(expected = RegistroExistenteException.class)
	public void testeRegistroExistenteException_3() throws RegistroExistenteException {
	    throw new RegistroExistenteException("",new RegistroExistenteException());
	}
	
	
	
	
}
