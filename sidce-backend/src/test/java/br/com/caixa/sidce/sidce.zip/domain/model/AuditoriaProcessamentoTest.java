package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AuditoriaProcessamentoTest {

	final AuditoriaProcessamento pojo = new AuditoriaProcessamento();
	Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	@Test
	public void testaPropriedades() {
		AuditoriaProcessamento AuditoriaProcessamento = new AuditoriaProcessamento();
		assertThat(AuditoriaProcessamento, hasProperty("id"));
		assertThat(AuditoriaProcessamento, hasProperty("nome"));
		assertThat(AuditoriaProcessamento, hasProperty("data"));
		assertThat(AuditoriaProcessamento, hasProperty("dataHoraProcessamento"));
		assertThat(AuditoriaProcessamento, hasProperty("quantidadeRegistros"));
		assertThat(AuditoriaProcessamento, hasProperty("origem"));
		assertThat(AuditoriaProcessamento, hasProperty("periodo"));
		assertThat(AuditoriaProcessamento, hasProperty("matricula"));
		assertThat(AuditoriaProcessamento, hasProperty("hostname"));
		assertThat(AuditoriaProcessamento, hasProperty("descricaoEvento"));
	}
	@Test
	public void testaConstrutores () {
		AuditoriaProcessamento.builder().toString();
		AuditoriaProcessamento.builder().build().toBuilder();
		assertThat(AuditoriaProcessamento.builder().id(1).build(), hasProperty("id"));
		assertThat(AuditoriaProcessamento.builder().nome("a").build(), hasProperty("nome"));
		assertThat(AuditoriaProcessamento.builder().data(new Date()).build(), hasProperty("data"));
		assertThat(AuditoriaProcessamento.builder().dataHoraProcessamento(new Date()).build(), hasProperty("dataHoraProcessamento"));
		assertThat(AuditoriaProcessamento.builder().quantidadeRegistros(1).build(), hasProperty("quantidadeRegistros"));
		assertThat(AuditoriaProcessamento.builder().origem("aa").build(), hasProperty("origem"));
		assertThat(AuditoriaProcessamento.builder().periodo(11).build(), hasProperty("periodo"));
		assertThat(AuditoriaProcessamento.builder().matricula("aa").build(), hasProperty("matricula"));
		assertThat(AuditoriaProcessamento.builder().hostname("aaa").build(), hasProperty("hostname"));
		assertThat(AuditoriaProcessamento.builder().descricaoEvento("aa").build(), hasProperty("descricaoEvento"));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(1);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(1, field.get(pojo), "AuditoriaProcessamento.setId");
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, 123);
		final int result = pojo.getId();
		assertEquals(123, result, "AuditoriaProcessamento.getId");
	}

	@Test
	public void testeSetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		pojo.setMatricula("P123456");
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		assertEquals("P123456", field.get(pojo), "AuditoriaProcessamento.setMatricula");
	}

	@Test
	public void testeGetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		field.set(pojo, "123456789");
		final String result = pojo.getMatricula();
		assertEquals("123456789", result, "AuditoriaProcessamento.getMatricula");
	}

	@Test
	public void testeSetterNome() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNome("cnpj_partido_2018.txt");
		final Field field = pojo.getClass().getDeclaredField("nome");
		field.setAccessible(true);
		assertEquals("cnpj_partido_2018.txt", field.get(pojo), "AuditoriaProcessamento.setNomeArquivoPartido");
	}

	@Test
	public void testeGetterNome() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nome");
		field.setAccessible(true);
		field.set(pojo, "nomeDeArquivo.txt");
		final String result = pojo.getNome();
		assertEquals("nomeDeArquivo.txt", result, "AuditoriaProcessamento.getNomeArquivoPartido");
	}

	@Test
	public void testeSetterOrigem() throws NoSuchFieldException, IllegalAccessException {
		pojo.setOrigem("origemQualquer");
		final Field field = pojo.getClass().getDeclaredField("origem");
		field.setAccessible(true);
		assertEquals("origemQualquer", field.get(pojo), "AuditoriaProcessamento.setOrigem");
	}

	@Test
	public void testeGetterOrigem() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("origem");
		field.setAccessible(true);
		field.set(pojo, "origemQualquer");
		final String result = pojo.getOrigem();
		assertEquals("origemQualquer", result, "AuditoriaProcessamento.getOrigem");
	}

	@Test
	public void testeSetterHostname() throws NoSuchFieldException, IllegalAccessException {
		pojo.setHostname("127.0.0.1");
		final Field field = pojo.getClass().getDeclaredField("hostname");
		field.setAccessible(true);
		assertEquals("127.0.0.1", field.get(pojo), "AuditoriaProcessamento.setHostname");
	}

	@Test
	public void testeGetterHostname() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("hostname");
		field.setAccessible(true);
		field.set(pojo, "hostnameAqui");
		final String result = pojo.getHostname();
		assertEquals("hostnameAqui", result, "AuditoriaProcessamento.getHostname");
	}

	@Test
	public void testeSetterDescricaoEvento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoEvento("Evento evento Evento");
		final Field field = pojo.getClass().getDeclaredField("descricaoEvento");
		field.setAccessible(true);
		assertEquals("Evento evento Evento", field.get(pojo), "AuditoriaProcessamento.setDescricaoEvento");
	}

	@Test
	public void testeGetterDescricaoEvento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoEvento");
		field.setAccessible(true);
		field.set(pojo, "Descrição de evento");
		final String result = pojo.getDescricaoEvento();
		assertEquals("Descrição de evento", result, "AuditoriaProcessamento.getDescricaoEvento");
	}
	
	@Test
	public void testeSetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPeriodo(201812);
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		assertEquals(201812, field.get(pojo), "AuditoriaProcessamento.setPeriodo");
	}

	@Test
	public void testeGetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		field.set(pojo, 201901);
		final int result = pojo.getPeriodo();
		assertEquals(201901, result, "AuditoriaProcessamento.getPeriodo");
	}
	
    @Test
	public void testeSetterDataHoraProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataHoraProcessamento(timestamp);
		final Field field = pojo.getClass().getDeclaredField("dataHoraProcessamento");
		field.setAccessible(true);
		assertEquals(timestamp, field.get(pojo), "AuditoriaProcessamento.setDtHoraCadastro");
	}

	@Test
	public void testeGetterDataHoraProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataHoraProcessamento");
		field.setAccessible(true);
		field.set(pojo, timestamp);
		final Date result = pojo.getDataHoraProcessamento();
		assertEquals(timestamp, result, "AuditoriaProcessamento.getDtHoraCadastro");
	}
	@Test
	public void testeSetterData() throws NoSuchFieldException, IllegalAccessException {
		pojo.setData(timestamp);
		final Field field = pojo.getClass().getDeclaredField("data");
		field.setAccessible(true);
		assertEquals(timestamp, field.get(pojo), "AuditoriaProcessamento.setData");
	}
	
	@Test
	public void testeGetterData() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("data");
		field.setAccessible(true);
		field.set(pojo, timestamp);
		final Date result = pojo.getData();
		assertEquals(timestamp, result, "AuditoriaProcessamento.getData");
	}
	@Test
	public void testeSetterQuantidadeRegistros() throws NoSuchFieldException, IllegalAccessException {
		pojo.setQuantidadeRegistros(1);
		final Field field = pojo.getClass().getDeclaredField("quantidadeRegistros");
		field.setAccessible(true);
		assertEquals(1, field.get(pojo), "AuditoriaProcessamento.setQuantidadeRegistros");
	}
	
	@Test
	public void testeGetterQuantidadeRegistros() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("quantidadeRegistros");
		field.setAccessible(true);
		field.set(pojo, 1);
		final int result = pojo.getQuantidadeRegistros();
		assertEquals(1, result, "AuditoriaProcessamento.getQuantidadeRegistros");
	}
	
	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo("123-123-123");
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals("123-123-123", field.get(pojo), "AuditoriaProcessamento.setCodigo");
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, "123456");
		final String result = pojo.getCodigo();
		assertEquals("123456", result, "AuditoriaProcessamento.getCodigo");
	}

}
