package br.com.caixa.sidce.arquitetura;

import static org.mockito.Mockito.mock;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import br.com.caixa.sidce.config.CorsFilter;

@DataJpaTest
@ComponentScan(
    basePackages = {
            "br.com.caixa.sidce.domain.service",
            "br.com.caixa.sidce.infraestructure.persistence.jpa",
            "br.com.caixa.sidce.interfaces.util"
    }
)
@RunWith(SpringRunner.class)
@SpringBootTest
public class CorsFilterTest {
	
	CorsFilter customFilter = new CorsFilter();
	
   @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDoFilter() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        FilterChain filterChain = mock(FilterChain.class);

        customFilter.doFilter(request, response, filterChain);
    }
	
}
