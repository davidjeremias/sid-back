package br.com.caixa.sidce.interfaces.controller.dto;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import br.com.caixa.sidce.domain.model.Banco;
import br.com.caixa.sidce.domain.model.Conta;
import br.com.caixa.sidce.domain.model.Extrato;
import br.com.caixa.sidce.domain.model.OrigemDestino;
import br.com.caixa.sidce.domain.model.Titular;
import br.com.caixa.sidce.interfaces.web.dto.VisualizacaoArquivosDTO;

public class VisualizacaoArquivosDTOTest {

	final VisualizacaoArquivosDTO pojo = VisualizacaoArquivosDTO.builder().build();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;

	Banco banco = Banco.builder().id(1).build();
	Conta conta = Conta.builder().id(1).build();
	Extrato extrato = Extrato.builder().id(1).build();
	OrigemDestino origemDestino = OrigemDestino.builder().id(1).build();
	Titular titular = Titular.builder().id(1).build();

	Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	@Test
	public void testaPropriedades() throws IntrospectionException {
		VisualizacaoArquivosDTO obj = VisualizacaoArquivosDTO.builder().build();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(VisualizacaoArquivosDTO.class)
				.getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}
		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		VisualizacaoArquivosDTO.builder().build().toBuilder();

		VisualizacaoArquivosDTO.builder().toString();
		assertThat(VisualizacaoArquivosDTO.builder().aba(string).build(), hasProperty("aba"));
		assertThat(VisualizacaoArquivosDTO.builder().banco(banco).build(), hasProperty("banco"));
		assertThat(VisualizacaoArquivosDTO.builder().cnpj(string).build(), hasProperty("cnpj"));
		assertThat(VisualizacaoArquivosDTO.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(VisualizacaoArquivosDTO.builder().conta(conta).build(), hasProperty("conta"));
		assertThat(VisualizacaoArquivosDTO.builder().extrato(extrato).build(), hasProperty("extrato"));
		assertThat(VisualizacaoArquivosDTO.builder().numeroAgencia(string).build(), hasProperty("numeroAgencia"));
		assertThat(VisualizacaoArquivosDTO.builder().numeroConta(string).build(), hasProperty("numeroConta"));
		assertThat(VisualizacaoArquivosDTO.builder().origemDestino(origemDestino).build(),
				hasProperty("origemDestino"));
		assertThat(VisualizacaoArquivosDTO.builder().titular(titular).build(), hasProperty("titular"));

	}

	@Test
	public void testeGetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroConta();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterTitular() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("titular");
		field.setAccessible(true);
		field.set(pojo, titular);
		final Titular result = pojo.getTitular();
		assertEquals(titular, result);
	}

	@Test
	public void testeGetterAba() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("aba");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getAba();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterBanco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("banco");
		field.setAccessible(true);
		field.set(pojo, banco);
		final Banco result = pojo.getBanco();
		assertEquals(banco, result);
	}

	@Test
	public void testeGetterExtrato() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("extrato");
		field.setAccessible(true);
		field.set(pojo, extrato);
		final Extrato result = pojo.getExtrato();
		assertEquals(extrato, result);
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroAgencia();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCnpj() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cnpj");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCnpj();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterOrigemDestino() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("origemDestino");
		field.setAccessible(true);
		field.set(pojo, origemDestino);
		final OrigemDestino result = pojo.getOrigemDestino();
		assertEquals(origemDestino, result);
	}

	@Test
	public void testeGetterConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("conta");
		field.setAccessible(true);
		field.set(pojo, conta);
		final Conta result = pojo.getConta();
		assertEquals(conta, result);
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterAba() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAba(string);
		final Field field = pojo.getClass().getDeclaredField("aba");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(string);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroConta(string);
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTitular() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTitular(titular);
		final Field field = pojo.getClass().getDeclaredField("titular");
		field.setAccessible(true);
		assertEquals(titular, field.get(pojo));
	}

	@Test
	public void testeSetterExtrato() throws NoSuchFieldException, IllegalAccessException {
		pojo.setExtrato(extrato);
		final Field field = pojo.getClass().getDeclaredField("extrato");
		field.setAccessible(true);
		assertEquals(extrato, field.get(pojo));
	}

	@Test
	public void testeSetterOrigemDestino() throws NoSuchFieldException, IllegalAccessException {
		pojo.setOrigemDestino(origemDestino);
		final Field field = pojo.getClass().getDeclaredField("origemDestino");
		field.setAccessible(true);
		assertEquals(origemDestino, field.get(pojo));
	}

	@Test
	public void testeSetterBanco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setBanco(banco);
		final Field field = pojo.getClass().getDeclaredField("banco");
		field.setAccessible(true);
		assertEquals(banco, field.get(pojo));
	}

	@Test
	public void testeSetterCnpj() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCnpj(string);
		final Field field = pojo.getClass().getDeclaredField("cnpj");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setConta(conta);
		final Field field = pojo.getClass().getDeclaredField("conta");
		field.setAccessible(true);
		assertEquals(conta, field.get(pojo));
	}
	
	@Test
	public void testConstrutores() {
		
		VisualizacaoArquivosDTO v1 = new VisualizacaoArquivosDTO(banco);
		VisualizacaoArquivosDTO v2 = new VisualizacaoArquivosDTO(conta);
		VisualizacaoArquivosDTO v3 = new VisualizacaoArquivosDTO(extrato);
		VisualizacaoArquivosDTO v4 = new VisualizacaoArquivosDTO(origemDestino);
		VisualizacaoArquivosDTO v5 = new VisualizacaoArquivosDTO(titular);
		VisualizacaoArquivosDTO v6 = new VisualizacaoArquivosDTO(banco, conta, extrato, origemDestino, titular);
		assertNotNull(v1);
		assertNotNull(v2);
		assertNotNull(v3);
		assertNotNull(v4);
		assertNotNull(v5);
		assertNotNull(v6);		
	}

}
