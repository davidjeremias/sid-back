package br.com.caixa.sidce.arquitetura.application;

import javax.servlet.http.HttpServletRequest;

import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import br.com.caixa.sidce.Application;


@SpringBootApplication(scanBasePackages = {
	    "br.com.caixa.sidce.interfaces.web",
	    "br.com.caixa.sidce.domain.service",
	    "br.com.caixa.sidce.domain.model",
	    "br.com.caixa.sidce.infraestructure.persistence.jpa",
	    "br.com.caixa.sidce.util.infraestructure.web",
	    "br.com.caixa.sidce.util.infraestructure.service",
	    "br.com.caixa.sidce.util.infraestructure.exception",
	    "br.com.caixa.sidce.interfaces.util",
	    "br.com.caixa.sidce.property"
	})
public class ApplicationTest {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
    @Bean
    @Scope(scopeName = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public AccessToken accessToken() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        return ((KeycloakSecurityContext) ((KeycloakAuthenticationToken) request.getUserPrincipal()).getCredentials()).getToken();
    }
}
