package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ArquivoTest {

	final Arquivo pojo = new Arquivo();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Long valorLong = 1L;
	byte[] arquivo = new byte[1];

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();
	AgendamentoETL agendamento = AgendamentoETL.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Arquivo obj = new Arquivo();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Arquivo.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		Arquivo.builder().build().toBuilder();
		Arquivo.builder().toString();
		assertThat(Arquivo.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(Arquivo.builder().descricaoArquivo(string).build(), hasProperty("descricaoArquivo"));
		assertThat(Arquivo.builder().dtHrCadastro(date).build(), hasProperty("dtHrCadastro"));
		assertThat(Arquivo.builder().id(integer).build(), hasProperty("id"));
		assertThat(Arquivo.builder().nomeArquivo(string).build(), hasProperty("nomeArquivo"));
		assertThat(Arquivo.builder().usuario(string).build(), hasProperty("usuario"));

	}

	@Test
	public void testeGetterUsuario() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("usuario");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getUsuario();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNomeArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeArquivo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeArquivo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDescricaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoArquivo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDescricaoArquivo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterArquivo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("arquivo");
		field.setAccessible(true);
		field.set(pojo, arquivo);
		final byte[] result = pojo.getArquivo();
		assertEquals(arquivo, result);
	}

	@Test
	public void testeGetterAgendamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("agendamento");
		field.setAccessible(true);
		field.set(pojo, agendamento);
		final AgendamentoETL result = pojo.getAgendamento();
		assertEquals(agendamento, result);
	}

	@Test
	public void testeGetterDtHrCadastro() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrCadastro");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtHrCadastro();
		assertEquals(date, result);
	}

	@Test
	public void testeSetterArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setArquivo(arquivo);
		final Field field = pojo.getClass().getDeclaredField("arquivo");
		field.setAccessible(true);
		assertEquals(arquivo, field.get(pojo));
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDtHrCadastro() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrCadastro(date);
		final Field field = pojo.getClass().getDeclaredField("dtHrCadastro");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeSetterNomeArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeArquivo(string);
		final Field field = pojo.getClass().getDeclaredField("nomeArquivo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterUsuario() throws NoSuchFieldException, IllegalAccessException {
		pojo.setUsuario(string);
		final Field field = pojo.getClass().getDeclaredField("usuario");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterAgendamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAgendamento(agendamento);
		final Field field = pojo.getClass().getDeclaredField("agendamento");
		field.setAccessible(true);
		assertEquals(agendamento, field.get(pojo));
	}

	@Test
	public void testeSetterDescricaoArquivo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoArquivo(string);
		final Field field = pojo.getClass().getDeclaredField("descricaoArquivo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
