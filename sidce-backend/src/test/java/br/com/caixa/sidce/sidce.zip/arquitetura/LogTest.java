package br.com.caixa.sidce.arquitetura;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import java.util.logging.Level;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import br.com.caixa.sidce.util.infraestructure.exception.GeneralRunTimeException;
import br.com.caixa.sidce.util.infraestructure.exception.NegocioException;
import br.com.caixa.sidce.util.infraestructure.log.Log;

@RunWith(MockitoJUnitRunner.class)
public class LogTest {

	@Test
	public void testLog() throws IOException {
		
		NegocioException ex = mock(NegocioException.class);
		
		Log.warn(LogTest.class, "Teste Log warn");
		Log.warn(LogTest.class, ex);
		Log.warn(LogTest.class, "Teste Log warn", ex);
		
		Log.debug(LogTest.class, "Teste Log debug");
		Log.debug(LogTest.class, ex);
		Log.debug(LogTest.class, "Teste Log debug", ex);
		
		Log.info(LogTest.class, "Teste Log info");
		Log.info(LogTest.class, ex);
		Log.info(LogTest.class, "Teste Log info", ex);
		
		Log.error(LogTest.class, "Teste Log error");
		Log.error(LogTest.class, ex);
		Log.error(LogTest.class, "Teste Log error", ex);
	}
	
	@Test(expected=GeneralRunTimeException.class)
	public void testLogExcpetion_1() throws IOException {
		NegocioException ex = mock(NegocioException.class);
		Log.log(LogTest.class, null, "", ex);
	}
	
	@Test(expected=GeneralRunTimeException.class)
	public void testLogExcpetion_2() throws IOException {
		NegocioException ex = mock(NegocioException.class);
		Level lv = mock(Level.class);
		Log.log(null, lv, "", ex);
	}
	
	@Test(expected=GeneralRunTimeException.class)
	public void testLogExcpetion_3() throws IOException {
		Level lv = mock(Level.class);
		Log.log(LogTest.class, lv, null, null);
	}
	
}
