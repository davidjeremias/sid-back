package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class OrigemDestinoTest {

	final OrigemDestino pojo = new OrigemDestino();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Long valorLong = 1L;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		OrigemDestino obj = new OrigemDestino();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(OrigemDestino.class)
				.getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		OrigemDestino.builder().build().toBuilder();

		OrigemDestino.builder().toString();
		assertThat(OrigemDestino.builder().auditoriaProcessamento(auditoriaprocessamento).build(),
				hasProperty("auditoriaProcessamento"));
		assertThat(OrigemDestino.builder().chaveExtrato(integer).build(), hasProperty("chaveExtrato"));
		assertThat(OrigemDestino.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(OrigemDestino.builder().codigoBanco(integer).build(), hasProperty("codigoBanco"));
		assertThat(OrigemDestino.builder().codigoBarras(string).build(), hasProperty("codigoBarras"));
		assertThat(OrigemDestino.builder().codigoOrigemDestino(integer).build(), hasProperty("codigoOrigemDestino"));
		assertThat(OrigemDestino.builder().cpfCnpj(string).build(), hasProperty("cpfCnpj"));
		assertThat(OrigemDestino.builder().descricaoDocumentoEndossante(string).build(),
				hasProperty("descricaoDocumentoEndossante"));
		assertThat(OrigemDestino.builder().id(integer).build(), hasProperty("id"));
		assertThat(OrigemDestino.builder().nomeDocumentoIdentificacao(string).build(),
				hasProperty("nomeDocumentoIdentificacao"));
		assertThat(OrigemDestino.builder().nomeEndossante(string).build(), hasProperty("nomeEndossante"));
		assertThat(OrigemDestino.builder().nomePessoa(string).build(), hasProperty("nomePessoa"));
		assertThat(OrigemDestino.builder().numeroAgencia(integer).build(), hasProperty("numeroAgencia"));
		assertThat(OrigemDestino.builder().numeroConta(string).build(), hasProperty("numeroConta"));
		assertThat(OrigemDestino.builder().numeroDocumentoIdentificacao(string).build(),
				hasProperty("numeroDocumentoIdentificacao"));
		assertThat(OrigemDestino.builder().numeroDocumentoTranscao(string).build(),
				hasProperty("numeroDocumentoTranscao"));
		assertThat(OrigemDestino.builder().observacao(string).build(), hasProperty("observacao"));
		assertThat(OrigemDestino.builder().perido(integer).build(), hasProperty("perido"));
		assertThat(OrigemDestino.builder().situacao(integer).build(), hasProperty("situacao"));
		assertThat(OrigemDestino.builder().tipoConta(integer).build(), hasProperty("tipoConta"));
		assertThat(OrigemDestino.builder().tipoPessoa(integer).build(), hasProperty("tipoPessoa"));
		assertThat(OrigemDestino.builder().valorTransacao(valorLong).build(), hasProperty("valorTransacao"));
		assertThat(OrigemDestino.builder().versao(integer).build(), hasProperty("versao"));

	}

	@Test
	public void testeGetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroConta();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigoBarras() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoBarras");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigoBarras();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigoOrigemDestino() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoOrigemDestino");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoOrigemDestino();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterPerido() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPerido();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterChaveExtrato() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("chaveExtrato");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getChaveExtrato();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterCpfCnpj() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cpfCnpj");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCpfCnpj();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterSituacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("situacao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getSituacao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		field.set(pojo, auditoriaprocessamento);
		final AuditoriaProcessamento result = pojo.getAuditoriaProcessamento();
		assertEquals(auditoriaprocessamento, result);
	}

	@Test
	public void testeGetterNomeDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeDocumentoIdentificacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeDocumentoIdentificacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoIdentificacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroDocumentoIdentificacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoConta();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterTipoPessoa() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoPessoa");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoPessoa();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterObservacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("observacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getObservacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getNumeroAgencia();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterDescricaoDocumentoEndossante() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoDocumentoEndossante");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDescricaoDocumentoEndossante();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroDocumentoTranscao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoTranscao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroDocumentoTranscao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterVersao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getVersao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterNomeEndossante() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeEndossante");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeEndossante();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNomePessoa() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomePessoa");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomePessoa();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoBanco();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterValorTransacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("valorTransacao");
		field.setAccessible(true);
		field.set(pojo, valorLong);
		final Long result = pojo.getValorTransacao();
		assertEquals(valorLong, result);
	}

	@Test
	public void testeSetterVersao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setVersao(integer);
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterSituacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setSituacao(integer);
		final Field field = pojo.getClass().getDeclaredField("situacao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoBanco(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterObservacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setObservacao(string);
		final Field field = pojo.getClass().getDeclaredField("observacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTipoPessoa() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoPessoa(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoPessoa");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(integer);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAuditoriaProcessamento(auditoriaprocessamento);
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		assertEquals(auditoriaprocessamento, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroDocumentoIdentificacao(string);
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoIdentificacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroConta(string);
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterChaveExtrato() throws NoSuchFieldException, IllegalAccessException {
		pojo.setChaveExtrato(integer);
		final Field field = pojo.getClass().getDeclaredField("chaveExtrato");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterNomePessoa() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomePessoa(string);
		final Field field = pojo.getClass().getDeclaredField("nomePessoa");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCpfCnpj() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCpfCnpj(string);
		final Field field = pojo.getClass().getDeclaredField("cpfCnpj");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNomeDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeDocumentoIdentificacao(string);
		final Field field = pojo.getClass().getDeclaredField("nomeDocumentoIdentificacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoOrigemDestino() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoOrigemDestino(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoOrigemDestino");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterPerido() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPerido(integer);
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoBarras() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoBarras(string);
		final Field field = pojo.getClass().getDeclaredField("codigoBarras");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroDocumentoTranscao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroDocumentoTranscao(string);
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoTranscao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNomeEndossante() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeEndossante(string);
		final Field field = pojo.getClass().getDeclaredField("nomeEndossante");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDescricaoDocumentoEndossante() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoDocumentoEndossante(string);
		final Field field = pojo.getClass().getDeclaredField("descricaoDocumentoEndossante");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterValorTransacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setValorTransacao(valorLong);
		final Field field = pojo.getClass().getDeclaredField("valorTransacao");
		field.setAccessible(true);
		assertEquals(valorLong, field.get(pojo));
	}

	@Test
	public void testeSetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoConta(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
