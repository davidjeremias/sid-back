package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ExtratoTest {

	final Extrato pojo = new Extrato();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Extrato obj = new Extrato();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Extrato.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		Extrato.builder().build().toBuilder();
		Extrato.builder().toString();
		assertThat(Extrato.builder().auditoriaProcessamento(auditoriaprocessamento).build(),
				hasProperty("auditoriaProcessamento"));
		assertThat(Extrato.builder().chaveExtrato(integer).build(), hasProperty("chaveExtrato"));
		assertThat(Extrato.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(Extrato.builder().codigoBanco(integer).build(), hasProperty("codigoBanco"));
		assertThat(Extrato.builder().dataLancamento(string).build(), hasProperty("dataLancamento"));
		assertThat(Extrato.builder().descricaoLancamento(string).build(), hasProperty("descricaoLancamento"));
		assertThat(Extrato.builder().documento(string).build(), hasProperty("documento"));
		assertThat(Extrato.builder().id(integer).build(), hasProperty("id"));
		assertThat(Extrato.builder().localTransacao(string).build(), hasProperty("localTransacao"));
		assertThat(Extrato.builder().naturezaLancamento(string).build(), hasProperty("naturezaLancamento"));
		assertThat(Extrato.builder().naturezaSaldo(string).build(), hasProperty("naturezaSaldo"));
		assertThat(Extrato.builder().numeroAgencia(integer).build(), hasProperty("numeroAgencia"));
		assertThat(Extrato.builder().numeroConta(string).build(), hasProperty("numeroConta"));
		assertThat(Extrato.builder().origem(string).build(), hasProperty("origem"));
		assertThat(Extrato.builder().perido(integer).build(), hasProperty("perido"));
		assertThat(Extrato.builder().tipoConta(integer).build(), hasProperty("tipoConta"));
		assertThat(Extrato.builder().tipoLancamento(integer).build(), hasProperty("tipoLancamento"));
		assertThat(Extrato.builder().valorLancamento(string).build(), hasProperty("valorLancamento"));
		assertThat(Extrato.builder().valorSaldo(string).build(), hasProperty("valorSaldo"));
		assertThat(Extrato.builder().versao(integer).build(), hasProperty("versao"));

	}

	@Test
	public void testeGetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroConta();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPerido() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPerido();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterChaveExtrato() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("chaveExtrato");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getChaveExtrato();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		field.set(pojo, auditoriaprocessamento);
		final AuditoriaProcessamento result = pojo.getAuditoriaProcessamento();
		assertEquals(auditoriaprocessamento, result);
	}

	@Test
	public void testeGetterTipoLancamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoLancamento");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoLancamento();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoConta();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterLocalTransacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("localTransacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getLocalTransacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNaturezaSaldo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("naturezaSaldo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNaturezaSaldo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterValorLancamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("valorLancamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getValorLancamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterNaturezaLancamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("naturezaLancamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNaturezaLancamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDocumento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("documento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDocumento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getNumeroAgencia();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterValorSaldo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("valorSaldo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getValorSaldo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterVersao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getVersao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterOrigem() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("origem");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getOrigem();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDataLancamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataLancamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDataLancamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDescricaoLancamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoLancamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDescricaoLancamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoBanco();
		assertEquals(integer, result);
	}

	@Test
	public void testeSetterOrigem() throws NoSuchFieldException, IllegalAccessException {
		pojo.setOrigem(string);
		final Field field = pojo.getClass().getDeclaredField("origem");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDocumento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDocumento(string);
		final Field field = pojo.getClass().getDeclaredField("documento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterVersao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setVersao(integer);
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoBanco(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(integer);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAuditoriaProcessamento(auditoriaprocessamento);
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		assertEquals(auditoriaprocessamento, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroConta(string);
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDescricaoLancamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoLancamento(string);
		final Field field = pojo.getClass().getDeclaredField("descricaoLancamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTipoLancamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoLancamento(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoLancamento");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterChaveExtrato() throws NoSuchFieldException, IllegalAccessException {
		pojo.setChaveExtrato(integer);
		final Field field = pojo.getClass().getDeclaredField("chaveExtrato");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterLocalTransacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setLocalTransacao(string);
		final Field field = pojo.getClass().getDeclaredField("localTransacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterValorSaldo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setValorSaldo(string);
		final Field field = pojo.getClass().getDeclaredField("valorSaldo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterPerido() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPerido(integer);
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterValorLancamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setValorLancamento(string);
		final Field field = pojo.getClass().getDeclaredField("valorLancamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNaturezaLancamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNaturezaLancamento(string);
		final Field field = pojo.getClass().getDeclaredField("naturezaLancamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNaturezaSaldo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNaturezaSaldo(string);
		final Field field = pojo.getClass().getDeclaredField("naturezaSaldo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterDataLancamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataLancamento(string);
		final Field field = pojo.getClass().getDeclaredField("dataLancamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoConta(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
