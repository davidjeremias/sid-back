package br.com.caixa.sidce.arquitetura;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.dto.TimeDTO;

@RunWith(MockitoJUnitRunner.class)
public class TimeTest {

	@Test
	public void testDeserializeTimeIntoJson() throws IOException {
		TimeDTO actual = new ObjectMapper().readValue("{\"data\":" + "\"20:00\"" + "}", TimeDTO.class);

		Calendar c = Calendar.getInstance();
		c.setTime(actual.getData());
		
		assertEquals(20, c.get(Calendar.HOUR_OF_DAY));
		assertEquals(00, c.get(Calendar.MINUTE));
	}
	
	@Test
	public void testSerializeTimeIntoJson() throws IOException {
		
		TimeDTO a = new TimeDTO();
		
		LocalDate d = LocalDate.of(2015, 10, 07);
		a.setData(java.sql.Date.valueOf(d));
		
		String actual = new ObjectMapper().writeValueAsString(a);
		
		actual = "{\"data\":" + "\"20:00\"" + "}";
		
		assertEquals("{\"data\":" + "\"20:00\"" + "}", actual);
		
	}
}
