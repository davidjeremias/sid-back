package br.com.caixa.sidce.interfaces.controller.dto;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.lang.reflect.Field;
import java.util.Date;

import org.junit.Test;

import br.com.caixa.sidce.interfaces.web.dto.FileDTO;

public class FileDTOTest {
	
	final FileDTO pojo = new FileDTO("name", "uri", "step");
	private Date data = new Date();
	
	@Test
	public void testaPropriedades() {
		FileDTO dto = new FileDTO("name", "uri", "step");
		assertThat(dto, hasProperty("fileName"));
		assertThat(dto, hasProperty("fileDownloadUri"));
		assertThat(dto, hasProperty("fileType"));
		assertThat(dto, hasProperty("size"));
		assertThat(dto, hasProperty("step"));
	}
	
	@Test
	public void testeSetterFileName() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFileName("Filenameteste");
		final Field field = pojo.getClass().getDeclaredField("fileName");
		field.setAccessible(true);
		assertEquals("Filenameteste", field.get(pojo), "ConsultaAgendamentoDTO.setFileName");
	}

	@Test
	public void testeGetterFileName() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("fileName");
		field.setAccessible(true);
		field.set(pojo, "testenome");
		final String result = pojo.getFileName();
		assertEquals("testenome", result, "ConsultaAgendamentoDTO.getFileName");
	}
	
	@Test
	public void testeSetterFileDownloadUri() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFileDownloadUri("caminho/pasta/arquivo.txt");
		final Field field = pojo.getClass().getDeclaredField("fileDownloadUri");
		field.setAccessible(true);
		assertEquals("caminho/pasta/arquivo.txt", field.get(pojo), "ConsultaAgendamentoDTO.setFileDownloadUri");
	}

	@Test
	public void testeGetterFileDownloadUri() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("fileDownloadUri");
		field.setAccessible(true);
		field.set(pojo, "caminho/pasta/arquivo.txt");
		final String result = pojo.getFileDownloadUri();
		assertEquals("caminho/pasta/arquivo.txt", result, "ConsultaAgendamentoDTO.getFileDownloadUri");
	}
	
	@Test
	public void testeSetterFileType() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFileType(".zip");
		final Field field = pojo.getClass().getDeclaredField("fileType");
		field.setAccessible(true);
		assertEquals(".zip", field.get(pojo), "ConsultaAgendamentoDTO.setFileType");
	}

	@Test
	public void testeGetterFileType() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("fileType");
		field.setAccessible(true);
		field.set(pojo, ".txt");
		final String result = pojo.getFileType();
		assertEquals(".txt", result, "ConsultaAgendamentoDTO.getFileType");
	}
	
	@Test
	public void testeSetterStep() throws NoSuchFieldException, IllegalAccessException {
		pojo.setStep("Entrada");
		final Field field = pojo.getClass().getDeclaredField("step");
		field.setAccessible(true);
		assertEquals("Entrada", field.get(pojo), "ConsultaAgendamentoDTO.setStep");
	}

	@Test
	public void testeGetterStep() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("step");
		field.setAccessible(true);
		field.set(pojo, "Consulta");
		final String result = pojo.getStep();
		assertEquals("Consulta", result, "ConsultaAgendamentoDTO.getStep");
	}

	@Test
	public void testeSetterSize() throws NoSuchFieldException, IllegalAccessException {
		long x = 10;
		pojo.setSize(10);
		final Field field = pojo.getClass().getDeclaredField("size");
		field.setAccessible(true);
		assertEquals(x, field.get(pojo), "ConsultaAgendamentoDTO.setSize");
	}

	@Test
	public void testeGetterSize() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("size");
		field.setAccessible(true);
		field.set(pojo, 10);
		final long result = pojo.getSize();
		assertEquals(10, result, "ConsultaAgendamentoDTO.getSize");
	}
	
	@Test
	public void testaConstrutor () {
		FileDTO fileDTP = new FileDTO("testeName", "testDownload", ".tst", 30);
		assertNotNull(fileDTP);
	}
}
