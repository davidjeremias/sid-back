package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TitularTest {

	final Titular pojo = new Titular();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Long valorLong = 1L;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Titular obj = new Titular();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Titular.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		Titular.builder().toString();
		Titular.builder().build().toBuilder();
		assertThat(Titular.builder().auditoriaProcessamento(auditoriaprocessamento).build(),
				hasProperty("auditoriaProcessamento"));
		assertThat(Titular.builder().cep(string).build(), hasProperty("cep"));
		assertThat(Titular.builder().cidade(string).build(), hasProperty("cidade"));
		assertThat(Titular.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(Titular.builder().codigoConta(integer).build(), hasProperty("codigoConta"));
		assertThat(Titular.builder().cpfCNPJ(string).build(), hasProperty("cpfCNPJ"));
		assertThat(Titular.builder().fimRelacionamento(string).build(), hasProperty("fimRelacionamento"));
		assertThat(Titular.builder().id(integer).build(), hasProperty("id"));
		assertThat(Titular.builder().inicioRelacionamento(string).build(), hasProperty("inicioRelacionamento"));
		assertThat(Titular.builder().logradouro(string).build(), hasProperty("logradouro"));
		assertThat(Titular.builder().nomeCompleto(string).build(), hasProperty("nomeCompleto"));
		assertThat(Titular.builder().nomeDocumentoIdentificacao(string).build(),
				hasProperty("nomeDocumentoIdentificacao"));
		assertThat(Titular.builder().numeroAgencia(integer).build(), hasProperty("numeroAgencia"));
		assertThat(Titular.builder().numeroConta(string).build(), hasProperty("numeroConta"));
		assertThat(Titular.builder().numeroDocumentoIdentificacao(string).build(),
				hasProperty("numeroDocumentoIdentificacao"));
		assertThat(Titular.builder().pais(string).build(), hasProperty("pais"));
		assertThat(Titular.builder().perido(integer).build(), hasProperty("perido"));
		assertThat(Titular.builder().pessoaInvestigada(integer).build(), hasProperty("pessoaInvestigada"));
		assertThat(Titular.builder().renda(valorLong).build(), hasProperty("renda"));
		assertThat(Titular.builder().telefone(string).build(), hasProperty("telefone"));
		assertThat(Titular.builder().tipoConta(integer).build(), hasProperty("tipoConta"));
		assertThat(Titular.builder().tipoPessoaTitular(integer).build(), hasProperty("tipoPessoaTitular"));
		assertThat(Titular.builder().tipoVinculo(string).build(), hasProperty("tipoVinculo"));
		assertThat(Titular.builder().uf(string).build(), hasProperty("uf"));
		assertThat(Titular.builder().ultimaAtualizacaoRenda(string).build(), hasProperty("ultimaAtualizacaoRenda"));
		assertThat(Titular.builder().versao(integer).build(), hasProperty("versao"));
		
		

	}

	@Test
	public void testeGetterCodigoConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoConta");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoConta();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroConta();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCep() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cep");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCep();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPerido() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPerido();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		field.set(pojo, auditoriaprocessamento);
		final AuditoriaProcessamento result = pojo.getAuditoriaProcessamento();
		assertEquals(auditoriaprocessamento, result);
	}

	@Test
	public void testeGetterTelefone() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("telefone");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getTelefone();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNomeCompleto() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeCompleto");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeCompleto();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterLogradouro() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("logradouro");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getLogradouro();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterRenda() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("renda");
		field.setAccessible(true);
		field.set(pojo, valorLong);
		final Long result = pojo.getRenda();
		assertEquals(valorLong, result);
	}

	@Test
	public void testeGetterNomeDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeDocumentoIdentificacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeDocumentoIdentificacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoIdentificacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroDocumentoIdentificacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoConta();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterCpfCNPJ() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cpfCNPJ");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCpfCNPJ();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterFimRelacionamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("fimRelacionamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getFimRelacionamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterTipoPessoaTitular() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoPessoaTitular");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipoPessoaTitular();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterInicioRelacionamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("inicioRelacionamento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getInicioRelacionamento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPais() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("pais");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getPais();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getNumeroAgencia();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterUltimaAtualizacaoRenda() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("ultimaAtualizacaoRenda");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getUltimaAtualizacaoRenda();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterUf() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("uf");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getUf();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterVersao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getVersao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterCidade() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("cidade");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCidade();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPessoaInvestigada() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("pessoaInvestigada");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPessoaInvestigada();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterTipoVinculo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipoVinculo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getTipoVinculo();
		assertEquals(string, result);
	}

	@Test
	public void testeSetterInicioRelacionamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setInicioRelacionamento(string);
		final Field field = pojo.getClass().getDeclaredField("inicioRelacionamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterVersao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setVersao(integer);
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCep() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCep(string);
		final Field field = pojo.getClass().getDeclaredField("cep");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterUltimaAtualizacaoRenda() throws NoSuchFieldException, IllegalAccessException {
		pojo.setUltimaAtualizacaoRenda(string);
		final Field field = pojo.getClass().getDeclaredField("ultimaAtualizacaoRenda");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterLogradouro() throws NoSuchFieldException, IllegalAccessException {
		pojo.setLogradouro(string);
		final Field field = pojo.getClass().getDeclaredField("logradouro");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterPais() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPais(string);
		final Field field = pojo.getClass().getDeclaredField("pais");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCidade() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCidade(string);
		final Field field = pojo.getClass().getDeclaredField("cidade");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterUf() throws NoSuchFieldException, IllegalAccessException {
		pojo.setUf(string);
		final Field field = pojo.getClass().getDeclaredField("uf");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterTelefone() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTelefone(string);
		final Field field = pojo.getClass().getDeclaredField("telefone");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoConta(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoConta");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterFimRelacionamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setFimRelacionamento(string);
		final Field field = pojo.getClass().getDeclaredField("fimRelacionamento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(integer);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterTipoVinculo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoVinculo(string);
		final Field field = pojo.getClass().getDeclaredField("tipoVinculo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroDocumentoIdentificacao(string);
		final Field field = pojo.getClass().getDeclaredField("numeroDocumentoIdentificacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAuditoriaProcessamento(auditoriaprocessamento);
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		assertEquals(auditoriaprocessamento, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroConta(string);
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterRenda() throws NoSuchFieldException, IllegalAccessException {
		pojo.setRenda(valorLong);
		final Field field = pojo.getClass().getDeclaredField("renda");
		field.setAccessible(true);
		assertEquals(valorLong, field.get(pojo));
	}

	@Test
	public void testeSetterTipoPessoaTitular() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoPessoaTitular(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoPessoaTitular");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterNomeDocumentoIdentificacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeDocumentoIdentificacao(string);
		final Field field = pojo.getClass().getDeclaredField("nomeDocumentoIdentificacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterPerido() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPerido(integer);
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCpfCNPJ() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCpfCNPJ(string);
		final Field field = pojo.getClass().getDeclaredField("cpfCNPJ");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNomeCompleto() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeCompleto(string);
		final Field field = pojo.getClass().getDeclaredField("nomeCompleto");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterPessoaInvestigada() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPessoaInvestigada(integer);
		final Field field = pojo.getClass().getDeclaredField("pessoaInvestigada");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterTipoConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipoConta(integer);
		final Field field = pojo.getClass().getDeclaredField("tipoConta");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
