package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import br.com.caixa.sidce.domain.model.Conta.ContaBuilder;

@RunWith(MockitoJUnitRunner.class)
public class ContaTest {

	final Conta pojo = new Conta();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		Conta obj = new Conta();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(Conta.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		Conta.builder().build().toBuilder();

		Conta.builder().toString();
		assertThat(Conta.builder().auditoriaProcessamento(auditoriaprocessamento).build(),
				hasProperty("auditoriaProcessamento"));
		assertThat(Conta.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(Conta.builder().codigoBanco(integer).build(), hasProperty("codigoBanco"));
		assertThat(Conta.builder().dataAbertura(string).build(), hasProperty("dataAbertura"));
		assertThat(Conta.builder().dataEncerramento(string).build(), hasProperty("dataEncerramento"));
		assertThat(Conta.builder().dtHrProcessamento(date).build(), hasProperty("dtHrProcessamento"));
		assertThat(Conta.builder().id(integer).build(), hasProperty("id"));
		assertThat(Conta.builder().movimentacao(integer).build(), hasProperty("movimentacao"));
		assertThat(Conta.builder().numeroAgencia(integer).build(), hasProperty("numeroAgencia"));
		assertThat(Conta.builder().numeroConta(string).build(), hasProperty("numeroConta"));
		assertThat(Conta.builder().perido(integer).build(), hasProperty("perido"));
		assertThat(Conta.builder().tipo(integer).build(), hasProperty("tipo"));
		assertThat(Conta.builder().versao(integer).build(), hasProperty("versao"));
	}

	@Test
	public void testeGetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNumeroConta();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterPerido() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getPerido();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		field.set(pojo, auditoriaprocessamento);
		final AuditoriaProcessamento result = pojo.getAuditoriaProcessamento();
		assertEquals(auditoriaprocessamento, result);
	}

	@Test
	public void testeGetterTipo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("tipo");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getTipo();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getNumeroAgencia();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterMovimentacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("movimentacao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getMovimentacao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getCodigo();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterVersao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getVersao();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterDataAbertura() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataAbertura");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDataAbertura();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtHrProcessamento();
		assertEquals(date, result);
	}

	@Test
	public void testeGetterDataEncerramento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dataEncerramento");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDataEncerramento();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getCodigoBanco();
		assertEquals(integer, result);
	}

	@Test
	public void testeSetterVersao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setVersao(integer);
		final Field field = pojo.getClass().getDeclaredField("versao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigoBanco() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigoBanco(integer);
		final Field field = pojo.getClass().getDeclaredField("codigoBanco");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo(string);
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroAgencia() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroAgencia(integer);
		final Field field = pojo.getClass().getDeclaredField("numeroAgencia");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterNumeroConta() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNumeroConta(string);
		final Field field = pojo.getClass().getDeclaredField("numeroConta");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterAuditoriaProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setAuditoriaProcessamento(auditoriaprocessamento);
		final Field field = pojo.getClass().getDeclaredField("auditoriaProcessamento");
		field.setAccessible(true);
		assertEquals(auditoriaprocessamento, field.get(pojo));
	}

	@Test
	public void testeSetterDataEncerramento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataEncerramento(string);
		final Field field = pojo.getClass().getDeclaredField("dataEncerramento");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterPerido() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPerido(integer);
		final Field field = pojo.getClass().getDeclaredField("perido");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterTipo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setTipo(integer);
		final Field field = pojo.getClass().getDeclaredField("tipo");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterDataAbertura() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDataAbertura(string);
		final Field field = pojo.getClass().getDeclaredField("dataAbertura");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterMovimentacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setMovimentacao(integer);
		final Field field = pojo.getClass().getDeclaredField("movimentacao");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

	@Test
	public void testeSetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrProcessamento(date);
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}
	
	@Test
	public void testeEqualsHashCode() {
		Conta c1, c2;
		ContaBuilder contaBuilder = Conta.builder().numeroAgencia(1).numeroConta("1").tipo(1);
		c1 = contaBuilder.build();
		c2 = contaBuilder.build();
		assertTrue(c1.equals(c2));
		assertEquals(c1.hashCode(), c2.hashCode());
		assertFalse(c1.equals(pojo));
		assertFalse(c1.equals(null));
		assertFalse(c1.equals(date));
		c1.setTipo(2);
		assertFalse(c1.equals(c2));
		c1.setNumeroConta("2");
		assertFalse(c1.equals(c2));
		c1.setNumeroAgencia(2);
		assertFalse(c1.equals(c2));
		c1 = c2;
		assertTrue(c1.equals(c2));
	}

}
