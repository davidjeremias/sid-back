package br.com.caixa.sidce.arquitetura;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.dto.SituacaoDTO;
import br.com.caixa.sidce.util.infraestructure.domain.model.SituacaoAtivo;

@RunWith(MockitoJUnitRunner.class)
public class SituacaoTest {

	@Test
	public void testDeserializeSituacaoIntoJson() throws IOException {
		SituacaoDTO actual = new ObjectMapper().readValue("{\"situacao\":" + "\"I\"" + "}", SituacaoDTO.class);
		assertEquals(SituacaoAtivo.I, actual.getSituacao());
	}
	
	@Test
	public void testSerializeSituacaoAtivaIntoJson() throws IOException {
		
		SituacaoDTO a = new SituacaoDTO();
		a.setSituacao(SituacaoAtivo.A);
		
		String actual = new ObjectMapper().writeValueAsString(a);
		
		assertEquals("{\"situacao\":" + "\"A\"" + "}", actual);
		
	}
	
	@Test
	public void testSerializeSituacaoInativoIntoJson() throws IOException {
		
		SituacaoDTO a = new SituacaoDTO();
		a.setSituacao(SituacaoAtivo.I);
		
		String actual = new ObjectMapper().writeValueAsString(a);
		
		assertEquals("{\"situacao\":" + "\"I\"" + "}", actual);
		
	}
}
