package br.com.caixa.sidce.interfaces.util;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.time.LocalDate;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

import br.com.caixa.sidce.util.infraestructure.exception.NegocioException;

@DataJpaTest
@TestPropertySource(properties = { "spring.jpa.hibernate.ddl-auto=create" })
@ComponentScan(basePackages = { "br.com.caixa.sidce.domain.service",
		"br.com.caixa.sidce.infraestructure.persistence.jpa", "br.com.caixa.sidce.interfaces.util" })
@RunWith(SpringRunner.class)
@SpringBootTest
public class FileStorageTest {

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	@Autowired
	FileStorage fs;

	LocalDate agora = LocalDate.now();

	MultipartFile testMultipartFile = new MockMultipartFile("user-file", "arquivoUm.txt", "txt",
			"test data".getBytes());

	@Before
	public void initializeFolders() throws IOException {

	}

	@Test
	public void testaSalvarArquivo() throws NegocioException {
		String fileName = fs.salvarArquivo(testMultipartFile, folder.getRoot().toPath());
		assertEquals(testMultipartFile.getOriginalFilename(), fileName);
	}
	
	@Test(expected=NegocioException.class)
	public void testaSalvarArquivoNomeErrado() throws NegocioException {
		MultipartFile testMultipartFileProblema = new MockMultipartFile("user-file", "arquivoUm..txt", "txt",
				"test data".getBytes());
		fs.salvarArquivo(testMultipartFileProblema, folder.getRoot().toPath());
	}
	@Test(expected=NegocioException.class)
	public void testaSalvarArquivoIOException() throws NegocioException {
		MultipartFile testMultipartFileProblema = new MockMultipartFile("user-file", "arquivoUm..txt", "txt",
				"test data".getBytes());
		fs.salvarArquivo(testMultipartFileProblema, folder.getRoot().toPath());
	}

}
