package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SituacaoSigiloTest {

	final SituacaoSigilo pojo = new SituacaoSigilo();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Long valorLong = 1L;

	AuditoriaProcessamento auditoriaprocessamento = AuditoriaProcessamento.builder().id(1).build();

	@Test
	public void testaPropriedades() throws IntrospectionException {
		SituacaoSigilo obj = new SituacaoSigilo();
		PropertyDescriptor[] propertyDescriptors = Introspector.getBeanInfo(SituacaoSigilo.class).getPropertyDescriptors();
		List<String> propertyNames = new ArrayList<String>(propertyDescriptors.length);
		for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
			propertyNames.add(propertyDescriptor.getName());
		}

		for (String property : propertyNames) {
			assertThat(obj, hasProperty(property));
		}
	}

	@Test
	public void testaConstrutores() {
		SituacaoSigilo.builder().build().toBuilder();
		SituacaoSigilo.builder().toString();
		assertThat(SituacaoSigilo.builder().descricaoSituacao(string).build(), hasProperty("descricaoSituacao"));
		assertThat(SituacaoSigilo.builder().dtHrCadastro(date).build(), hasProperty("dtHrCadastro"));
		assertThat(SituacaoSigilo.builder().id(integer).build(), hasProperty("id"));
		assertThat(SituacaoSigilo.builder().nomeSituacao(string).build(), hasProperty("nomeSituacao"));
	}

	@Test
	public void testeGetterDescricaoSituacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoSituacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getDescricaoSituacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, integer);
		final Integer result = pojo.getId();
		assertEquals(integer, result);
	}

	@Test
	public void testeGetterNomeSituacao() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeSituacao");
		field.setAccessible(true);
		field.set(pojo, string);
		final String result = pojo.getNomeSituacao();
		assertEquals(string, result);
	}

	@Test
	public void testeGetterDtHrCadastro() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrCadastro");
		field.setAccessible(true);
		field.set(pojo, date);
		final Date result = pojo.getDtHrCadastro();
		assertEquals(date, result);
	}

	@Test
	public void testeSetterNomeSituacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeSituacao(string);
		final Field field = pojo.getClass().getDeclaredField("nomeSituacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterDtHrCadastro() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrCadastro(date);
		final Field field = pojo.getClass().getDeclaredField("dtHrCadastro");
		field.setAccessible(true);
		assertEquals(date, field.get(pojo));
	}

	@Test
	public void testeSetterDescricaoSituacao() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoSituacao(string);
		final Field field = pojo.getClass().getDeclaredField("descricaoSituacao");
		field.setAccessible(true);
		assertEquals(string, field.get(pojo));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(integer);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(integer, field.get(pojo));
	}

}
