package br.com.caixa.sidce.interfaces.web;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.security.Principal;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.caixa.sidce.arquitetura.application.ApplicationTest;
import br.com.caixa.sidce.domain.model.AgendamentoETL;
import br.com.caixa.sidce.domain.service.AgendamentoETLService;
import br.com.caixa.sidce.interfaces.util.FileStorage;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@WebMvcTest(controllers  = {AgendamentoETLController.class}, secure = false)
@ContextConfiguration(classes={ApplicationTest.class})
public class AgendamentoETLControllerTest  {
	
	 	@Autowired
	    protected MockMvc mockMvc;
	    
	    @MockBean
	    private AgendamentoETLService service;
	    
	    @MockBean
	    private FileStorage file;
	    
	    @Mock
		private Principal principal = Mockito.mock(Principal.class);
	    
	    private ObjectMapper mapper = new ObjectMapper();
	    
	    @Before
	    public void setup() throws Exception{
	    	when(principal.getName()).thenReturn("user");
	        AgendamentoETLController agendamentoController= new AgendamentoETLController(service);       
	        mockMvc = MockMvcBuilders.standaloneSetup(agendamentoController, file, service).build();
	    }
    
	    @Test
	    public void getArquivoById() throws Exception {
    	
	        mockMvc.perform(get("/api/arquivos/1")
	              .contentType(MediaType.APPLICATION_JSON)
	              .accept(MediaType.APPLICATION_JSON))
	              .andDo(print())
	              .andExpect(status().isNotFound());
	    }
	    
	    @Test
	    public void getArquivoFindAll() throws Exception {
    	
	        mockMvc.perform(get("/api/arquivos")
	              .contentType(MediaType.APPLICATION_JSON)
	              .accept(MediaType.APPLICATION_JSON))
	              .andDo(print())
	              .andExpect(status().isNoContent());
	    }
	    
	    @Test
	    public void putArquivo() throws Exception {
	    	
	    	AgendamentoETL agendamento = AgendamentoETL.builder()
					.matricula("")
					.periodo(201801)
					.descricaoEvento("desc")
					.dtHoraCadastro(new Date())
					.dtHrProcessamento(new Date())
					.nomeArquivoCandidato("")
					.nomeArquivoPartido("")
					.codigo("")
					.hostname("")
					.id(1)
					.build();
    	
	        mockMvc.perform(put("/api/arquivos")
	        	  .content(mapper.writeValueAsString(agendamento))
	              .contentType(MediaType.APPLICATION_JSON)
	              .accept(MediaType.APPLICATION_JSON))
	              .andDo(print())
	              .andExpect(status().isOk());
	    }
	    
	    @Test
	    public void deleteArquivo() throws Exception {
	    	
	        mockMvc.perform(delete("/api/arquivos/1")
	              .contentType(MediaType.APPLICATION_JSON)
	              .accept(MediaType.APPLICATION_JSON))
	              .andDo(print())
	              .andExpect(status().isNotFound());
	    }
	    
	    @Test
		public void patchArquivo() throws Exception {
	    	
	    	AgendamentoETL agendamento = AgendamentoETL.builder()
					.matricula("")
					.periodo(201801)
					.descricaoEvento("desc")
					.dtHoraCadastro(new Date())
					.dtHrProcessamento(new Date())
					.nomeArquivoCandidato("")
					.nomeArquivoPartido("")
					.codigo("")
					.hostname("")
					.build();

			mockMvc.perform(
					MockMvcRequestBuilders.patch("/api/arquivos/1").content(mapper.writeValueAsString(agendamento))
							.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andExpect(status().isInternalServerError());
		}
	    
	    @Test
		public void postAgendamento() throws Exception {
	    	
	    	AgendamentoETL agendamento = AgendamentoETL.builder()
					.matricula("")
					.periodo(201801)
					.descricaoEvento("desc")
					.dtHoraCadastro(new Date())
					.dtHrProcessamento(new Date())
					.nomeArquivoCandidato("")
					.nomeArquivoPartido("")
					.codigo("")
					.hostname("")
					.id(1)
					.build();

			mockMvc.perform(
					MockMvcRequestBuilders.post("/api/arquivos").content(mapper.writeValueAsString(agendamento))
							.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
					.andDo(print()).andExpect(status().isBadRequest());
		}
	    
	    @Test
	    public void testuploadMultipleFiles() throws Exception {
	    	mockMvc.perform(
	    	MockMvcRequestBuilders.multipart("/api/arquivos/uploadArquivosTSE")
	    		.file(new MockMultipartFile("arquivo", "conteudo".getBytes()))
	    		.file(new MockMultipartFile("outro-arquivo", "conteudo".getBytes()))
	    		.principal(principal))
	    	.andExpect(status().isOk());
	    }
	    
}

