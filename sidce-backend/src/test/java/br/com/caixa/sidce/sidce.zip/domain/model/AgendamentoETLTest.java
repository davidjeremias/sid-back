package br.com.caixa.sidce.domain.model;

import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;
import static org.testng.Assert.assertEquals;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AgendamentoETLTest {

	final AgendamentoETL pojo = new AgendamentoETL();
	Date date = new Date();
	String string = "Lorem Ipsum";
	Integer integer = 1;
	Timestamp timestamp = new Timestamp(System.currentTimeMillis());

	@Test
	public void testaPropriedades() {
		AgendamentoETL agendamentoETL = new AgendamentoETL();
		assertThat(agendamentoETL, hasProperty("id"));
		assertThat(agendamentoETL, hasProperty("dtHoraCadastro"));
		assertThat(agendamentoETL, hasProperty("matricula"));
		assertThat(agendamentoETL, hasProperty("periodo"));
		assertThat(agendamentoETL, hasProperty("nomeArquivoPartido"));
		assertThat(agendamentoETL, hasProperty("nomeArquivoCandidato"));
		assertThat(agendamentoETL, hasProperty("hostname"));
		assertThat(agendamentoETL, hasProperty("descricaoEvento"));
		assertThat(agendamentoETL, hasProperty("dtHrProcessamento"));
		assertThat(agendamentoETL, hasProperty("codigo"));
	}

	@Test
	public void testaConstrutores() {
		AgendamentoETL.builder().toString();
		assertThat(AgendamentoETL.builder().codigo(string).build(), hasProperty("codigo"));
		assertThat(AgendamentoETL.builder().descricaoEvento(string).build(), hasProperty("descricaoEvento"));
		assertThat(AgendamentoETL.builder().dtHoraCadastro(date).build(), hasProperty("dtHoraCadastro"));
		assertThat(AgendamentoETL.builder().dtHrProcessamento(date).build(), hasProperty("dtHrProcessamento"));
		assertThat(AgendamentoETL.builder().hostname(string).build(), hasProperty("hostname"));
		assertThat(AgendamentoETL.builder().id(integer).build(), hasProperty("id"));
		assertThat(AgendamentoETL.builder().matricula(string).build(), hasProperty("matricula"));
		assertThat(AgendamentoETL.builder().nomeArquivoCandidato(string).build(), hasProperty("nomeArquivoCandidato"));
		assertThat(AgendamentoETL.builder().nomeArquivoPartido(string).build(), hasProperty("nomeArquivoPartido"));
		assertThat(AgendamentoETL.builder().periodo(integer).build(), hasProperty("periodo"));
	}

	@Test
	public void testeSetterId() throws NoSuchFieldException, IllegalAccessException {
		pojo.setId(1);
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		assertEquals(1, field.get(pojo), "AgendamentoETL.setId");
	}

	@Test
	public void testeGetterId() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("id");
		field.setAccessible(true);
		field.set(pojo, 123);
		final int result = pojo.getId();
		assertEquals(123, result, "AgendamentoETL.getId");
	}

	@Test
	public void testeSetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		pojo.setMatricula("P123456");
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		assertEquals("P123456", field.get(pojo), "AgendamentoETL.setMatricula");
	}

	@Test
	public void testeGetterMatricula() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("matricula");
		field.setAccessible(true);
		field.set(pojo, "123456789");
		final String result = pojo.getMatricula();
		assertEquals("123456789", result, "AgendamentoETL.getMatricula");
	}

	@Test
	public void testeSetterNomeArquivoPartido() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeArquivoPartido("cnpj_partido_2018.txt");
		final Field field = pojo.getClass().getDeclaredField("nomeArquivoPartido");
		field.setAccessible(true);
		assertEquals("cnpj_partido_2018.txt", field.get(pojo), "AgendamentoETL.setNomeArquivoPartido");
	}

	@Test
	public void testeGetterNomeArquivoPartido() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeArquivoPartido");
		field.setAccessible(true);
		field.set(pojo, "nomeDeArquivo.txt");
		final String result = pojo.getNomeArquivoPartido();
		assertEquals("nomeDeArquivo.txt", result, "AgendamentoETL.getNomeArquivoPartido");
	}

	@Test
	public void testeSetterNomeArquivoCandidato() throws NoSuchFieldException, IllegalAccessException {
		pojo.setNomeArquivoCandidato("cnpj_candidato_2018.txt");
		final Field field = pojo.getClass().getDeclaredField("nomeArquivoCandidato");
		field.setAccessible(true);
		assertEquals("cnpj_candidato_2018.txt", field.get(pojo), "AgendamentoETL.setNomeArquivoCandidato");
	}

	@Test
	public void testeGetterNomeArquivoCandidato() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("nomeArquivoCandidato");
		field.setAccessible(true);
		field.set(pojo, "nomeDeArquivo.txt");
		final String result = pojo.getNomeArquivoCandidato();
		assertEquals("nomeDeArquivo.txt", result, "AgendamentoETL.getNomeArquivoCandidato");
	}

	@Test
	public void testeSetterHostname() throws NoSuchFieldException, IllegalAccessException {
		pojo.setHostname("127.0.0.1");
		final Field field = pojo.getClass().getDeclaredField("hostname");
		field.setAccessible(true);
		assertEquals("127.0.0.1", field.get(pojo), "AgendamentoETL.setHostname");
	}

	@Test
	public void testeGetterHostname() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("hostname");
		field.setAccessible(true);
		field.set(pojo, "hostnameAqui");
		final String result = pojo.getHostname();
		assertEquals("hostnameAqui", result, "AgendamentoETL.getHostname");
	}

	@Test
	public void testeSetterDescricaoEvento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDescricaoEvento("Evento evento Evento");
		final Field field = pojo.getClass().getDeclaredField("descricaoEvento");
		field.setAccessible(true);
		assertEquals("Evento evento Evento", field.get(pojo), "AgendamentoETL.setDescricaoEvento");
	}

	@Test
	public void testeGetterDescricaoEvento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("descricaoEvento");
		field.setAccessible(true);
		field.set(pojo, "Descrição de evento");
		final String result = pojo.getDescricaoEvento();
		assertEquals("Descrição de evento", result, "AgendamentoETL.getDescricaoEvento");
	}

	@Test
	public void testeSetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setPeriodo(201812);
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		assertEquals(201812, field.get(pojo), "AgendamentoETL.setPeriodo");
	}

	@Test
	public void testeGetterPeriodo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("periodo");
		field.setAccessible(true);
		field.set(pojo, 201901);
		final int result = pojo.getPeriodo();
		assertEquals(201901, result, "AgendamentoETL.getPeriodo");
	}

	@Test
	public void testeSetterDtHoraCadastro() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHoraCadastro(timestamp);
		final Field field = pojo.getClass().getDeclaredField("dtHoraCadastro");
		field.setAccessible(true);
		assertEquals(timestamp, field.get(pojo), "AgendamentoETL.setDtHoraCadastro");
	}

	@Test
	public void testeGetterDtHoraCadastro() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHoraCadastro");
		field.setAccessible(true);
		field.set(pojo, timestamp);
		final Date result = pojo.getDtHoraCadastro();
		assertEquals(timestamp, result, "AgendamentoETL.getDtHoraCadastro");
	}

	@Test
	public void testeSetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		pojo.setDtHrProcessamento(timestamp);
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		assertEquals(timestamp, field.get(pojo), "AgendamentoETL.setDtHrProcessamento");
	}

	@Test
	public void testeGetterDtHrProcessamento() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("dtHrProcessamento");
		field.setAccessible(true);
		field.set(pojo, timestamp);
		final Date result = pojo.getDtHrProcessamento();
		assertEquals(timestamp, result, "AgendamentoETL.getDtHrProcessamento");
	}

	@Test
	public void testeSetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		pojo.setCodigo("AAA111-BBB222-CCC333-DDD444");
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		assertEquals("AAA111-BBB222-CCC333-DDD444", field.get(pojo), "AgendamentoETL.setCodigo");
	}

	@Test
	public void testeGetterCodigo() throws NoSuchFieldException, IllegalAccessException {
		final Field field = pojo.getClass().getDeclaredField("codigo");
		field.setAccessible(true);
		field.set(pojo, "AAA111-BBB222-CCC333-DDD444");
		final String result = pojo.getCodigo();
		assertEquals("AAA111-BBB222-CCC333-DDD444", result, "AgendamentoETL.getCodigo");
	}
}
