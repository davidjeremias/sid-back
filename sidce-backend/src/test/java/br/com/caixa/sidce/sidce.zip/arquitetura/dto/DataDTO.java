package br.com.caixa.sidce.arquitetura.dto;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.DataHoraDeserializer;
import br.com.caixa.sidce.util.infraestructure.domain.model.serializer.DataSerializer;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataDTO {
	
	@JsonSerialize(using=DataSerializer.class)
	@JsonDeserialize(using=DataHoraDeserializer.class)
	private Date data;
	   
}
